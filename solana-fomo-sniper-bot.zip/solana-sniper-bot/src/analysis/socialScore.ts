import type { SocialXReport } from "./social.js";
import type { TelegramReport } from "./telegram.js";
import axios from "axios";
import { config } from "../config/index.js";
import { childLogger } from "../utils/logger.js";

const log = childLogger("socialScore");

export interface SocialScoreReport {
  score: number; // 0-100, higher = stronger organic social signal
  breakdown: { source: string; points: number; detail: string }[];
}

/** Discord's public widget endpoint requires no auth but only returns data
 * if the server owner has enabled "Server Widget" in settings — very
 * common for public memecoin Discords, but not guaranteed. Returns null
 * (not 0) when the widget isn't enabled, so callers can tell "no signal"
 * apart from "confirmed zero activity". */
async function getDiscordPresence(guildId: string): Promise<number | null> {
  try {
    const { data } = await axios.get(`https://discord.com/api/guilds/${guildId}/widget.json`, {
      timeout: 4000,
    });
    return data.presence_count ?? null;
  } catch {
    return null;
  }
}

export async function scoreSocial(params: {
  x: SocialXReport;
  telegram: TelegramReport;
  discordGuildId?: string | null;
}): Promise<SocialScoreReport> {
  const breakdown: SocialScoreReport["breakdown"] = [];

  if (params.x.available) {
    const velocityPoints = Math.min(20, Math.round(params.x.mentionVelocityPerMin * 2));
    breakdown.push({ source: "x_velocity", points: velocityPoints, detail: `${params.x.mentionVelocityPerMin.toFixed(1)} mentions/min` });

    const sentimentPoints = Math.round(((params.x.sentimentScore + 1) / 2) * 15);
    breakdown.push({ source: "x_sentiment", points: sentimentPoints, detail: `sentiment ${params.x.sentimentScore.toFixed(2)}` });

    const influencerPoints = Math.min(15, params.x.influencerMentions.length * 5);
    breakdown.push({ source: "x_influencers", points: influencerPoints, detail: `${params.x.influencerMentions.length} accounts ≥10k followers` });

    const botPenalty = -Math.round(params.x.botLikelihoodAvg * 15);
    breakdown.push({ source: "x_bot_penalty", points: botPenalty, detail: `avg bot likelihood ${params.x.botLikelihoodAvg.toFixed(2)}` });
  }

  if (params.telegram.available) {
    const memberPoints = params.telegram.memberCount ? Math.min(20, Math.round(Math.log10(params.telegram.memberCount + 1) * 6)) : 0;
    breakdown.push({ source: "telegram_members", points: memberPoints, detail: `${params.telegram.memberCount ?? 0} members` });

    const activityPoints = Math.min(15, Math.round(params.telegram.messageRatePerMin));
    breakdown.push({ source: "telegram_activity", points: activityPoints, detail: `${params.telegram.messageRatePerMin.toFixed(1)} msg/min` });

    const spamPenalty = -Math.round(params.telegram.spamRatioEstimate * 15);
    breakdown.push({ source: "telegram_spam_penalty", points: spamPenalty, detail: `spam ratio ${params.telegram.spamRatioEstimate.toFixed(2)}` });
  }

  if (params.discordGuildId) {
    const presence = await getDiscordPresence(params.discordGuildId);
    if (presence !== null) {
      const points = Math.min(10, Math.round(Math.log10(presence + 1) * 4));
      breakdown.push({ source: "discord_presence", points, detail: `${presence} online` });
    }
  }

  const score = Math.max(0, Math.min(100, breakdown.reduce((sum, b) => sum + b.points, 0)));
  return { score, breakdown };
}
