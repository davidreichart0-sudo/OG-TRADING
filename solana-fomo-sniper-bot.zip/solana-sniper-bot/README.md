# Solana FOMO Sniper Bot

Automated new-token detection, multi-source analysis, and (paper or live) trading for the [FOMO](https://fomo.family) ecosystem on Solana, with an MCP server for monitoring/config from Claude.

**Runs at $0 by default.** See `.env.example` for exactly what's free-forever, free-with-signup, and paid-and-skippable.

> ⚠️ **Read before running with real funds:** Memecoins are extremely high risk. Most new tokens lose most or all of their value — including ones that pass every check this bot runs. Nothing in this project is financial advice. No risk score, however thorough, is a guarantee against rug pulls, honeypots, or total loss. Paper-trade first. Only ever fund the bot's wallet with money you're fully prepared to lose. See `docs/SETUP.md` → "Going live" for the full checklist.

## What's fully working out of the box

- New-token detection via Solana WebSocket logs (`src/core/listener.ts`), plus an optional Yellowstone gRPC path for paid low-latency feeds
- On-chain due diligence: mint/freeze authority, LP burn check, holder concentration, buy/sell ratio, honeypot simulation, wallet-cluster detection (`src/analysis/onchain.ts`)
- Website due diligence: SSL, domain age, social-link extraction, copycat-name detection (`src/analysis/website.ts`)
- Transparent, rule-based risk engine — every point is traceable to a named factor, not a black box (`src/analysis/riskEngine.ts`)
- Paper trading (default) and live trading (double opt-in) via Jupiter swaps, with position-size and daily-loss caps enforced in code (`src/trading/executor.ts`)
- Tiered take-profit, trailing stop, stop-loss, and on-chain-signal emergency exit (`src/trading/positionManager.ts`)
- Live dashboard (`dashboard/index.html`) and Telegram alerts (`src/alerts/telegramAlerts.ts`)
- MCP server for read/monitoring + live threshold tuning from Claude Desktop (`src/mcp/server.ts`) — deliberately cannot place trades or enable live mode itself, see that file's top comment
- PostgreSQL + Redis + Docker Compose, structured logging with automatic secret redaction

## What needs your own (free) API keys to activate

- **X/Twitter mention analysis** — optional, no viable free tier exists; the bot runs fine without it
- **Smart-money wallet history** — works via raw RPC by default; add a free Helius key for faster lookups
- **Swap execution** — needs a free Jupiter Developer Platform key (Lite plan, $0)

## Quick start

```bash
npm install
cp .env.example .env        # fill in FOMO_PROGRAM_ID at minimum — see docs/SETUP.md §2
docker compose up -d postgres redis
npm run prisma:migrate
npm run dev
```

Full walkthrough, including finding `FOMO_PROGRAM_ID`, Telegram/Jupiter/Helius setup, connecting the MCP server to Claude Desktop, and the "going live" checklist: **[docs/SETUP.md](docs/SETUP.md)**.

## Feature map (spec → implementation)

| Requested area | File(s) |
|---|---|
| 1. Tech stack | `package.json`, `docker-compose.yml` |
| 2. Speed / WebSockets, no polling | `src/core/listener.ts` |
| 3. X / Telegram / website analysis | `src/analysis/social.ts`, `telegram.ts`, `website.ts` |
| 4. On-chain analysis | `src/analysis/onchain.ts` |
| 5. Smart money analysis | `src/analysis/smartMoney.ts` |
| 6. Risk engine | `src/analysis/riskEngine.ts` |
| 7. Social score | `src/analysis/socialScore.ts` |
| 8. Buy strategy | `src/trading/strategy.ts` |
| 9. Profit strategy | `src/trading/positionManager.ts` (take-profit tiers, trailing stop) |
| 10. Position monitoring | `src/trading/positionManager.ts` |
| 11. Dashboard | `dashboard/index.html`, `src/api/server.ts` |
| 12. Alerts | `src/alerts/telegramAlerts.ts` |
| 13. Paper trading | `src/trading/executor.ts` (mode: "PAPER") |
| 14. Security | `src/utils/logger.ts` (redaction), `.env`-only secrets, `src/utils/rpcConnection.ts` (retry/fallback) |
| 15. Documentation | `docs/SETUP.md` |

## Known limitations, stated plainly

- `FOMO_PROGRAM_ID` and the pool/liquidity-reserve reader are generic heuristics, not FOMO's exact instruction layout (which isn't publicly documented) — see `docs/SETUP.md §2`. Liquidity currently reports as "unknown" (handled conservatively, not as zero) until this is wired up with FOMO's real IDL.
- The risk/social scores are transparent, tunable heuristics — treat them as one input, not a verdict. A token can pass every check here and still go to zero.
- This was built and reviewed carefully but **not compiled or run** in this environment (no network access here to `npm install`) — run `npm run typecheck` yourself after installing before trusting it with real funds.
- Free-tier RPC (the default) is genuinely slower than what paid competitors run on — see the cost banner in `.env.example`.
